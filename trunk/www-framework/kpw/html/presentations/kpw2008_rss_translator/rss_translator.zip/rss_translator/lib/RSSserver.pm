package RSSserver;

use strict;
use warnings;
use base qw(HTTP::Server::Simple::CGI);
use Translate::JP2KR;

sub handle_request {
    my ($self, $cgi) = @_;

    my $REQUEST_URI = $ENV{REQUEST_URI};
    print STDERR "REQUEST_URI:$REQUEST_URI from ".$ENV{REMOTE_ADDR}."\n";
    my ( $target, $url) = $REQUEST_URI =~ m|/(.*?)/(.+)|;
    print STDERR "TARGET:$target URL:$url\n";

    eval {
        no strict 'refs';
        *{"Translate::$target\::translate"}->($url);
    };
    if ($@) {
        print "HTTP/1.0 Error 400 - Bad request\r\n";
        print "Content-Type text/plain \r\n\r\n";
        print "Error 400 - Bad request\n";

        print STDERR "Bad Request $@\n";
    }
    else {
        print STDERR "End Processing\n";
    }

}

1;
