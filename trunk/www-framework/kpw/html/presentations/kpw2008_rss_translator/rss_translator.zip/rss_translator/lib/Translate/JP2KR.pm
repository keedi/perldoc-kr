package Translate::JP2KR;

use strict;
use warnings;
use LWP;
use Encode;
use XML::FeedPP;

my $translator = 'http://j2k.naver.com/j2k.php/korean/';
my $translator2 = 'http://www.excite.co.jp/world/korean/web/?wb_url=';

sub translate {
    my $url = shift;

    my $agent = LWP::UserAgent->new();

    my ($start, $end);
    my $res = $agent->get($url);
    if ($res->is_success) {
        my $RSS = $res->content;
        #print STDERR $RSS."\n";
        ($start,$end) = $RSS =~ m/(<.*?>).+(<\/.*?>)/sm;
        #print STDERR "start:$start\nend:$end\n";
    }
    else {
        print STDERR "HTTP request error\n";
        return 0;
    }

    my $res2 = $agent->get($translator.$url);

    if ($res2->is_success) {
        my $trans = $res2->content;
        my ($RSS2) = $trans =~ m/(\Q$start\E.+\Q$end\E)/sm;
        #print STDERR $RSS2."\n";
        #print STDERR "start:$1\nend:$3\n";

        print "HTTP/1.0 200 OK\r\n";
        print "Content-Type: application/xhtml+xml\r\n\r\n";
        $RSS2 = Encode::encode("utf-8",Encode::decode("euc-kr",$RSS2));

        my $feed = XML::FeedPP->new($RSS2);
        #print STDERR "Title: ", $feed->title(), "\n";
        #print STDERR "Date: ", $feed->pubDate(), "\n";
        #print STDERR "link: ", $feed->link(), "\n";
        $feed->link( $translator2.$feed->link() );
        #print STDERR "link(modifiled): ", $feed->link(), "\n";
        foreach my $item ( $feed->get_item() ) {
            #print STDERR "Title: ", $item->title(), "\n";
            #print STDERR "URL: ", $item->link(), "\n";
            $item->link( $translator2.$item->link() );
            #print STDERR "URL(modifiled): ", $item->link(), "\n";
            #print STDERR "Content: ", $item->description(), "\n";
            #print STDERR "------------------------------------------------\n";
        }
        print $feed->to_string("utf-8");
    }
    else {
        print STDERR "HTTP request error\n";
        return 0;
    }

    return 1;
}

1;
