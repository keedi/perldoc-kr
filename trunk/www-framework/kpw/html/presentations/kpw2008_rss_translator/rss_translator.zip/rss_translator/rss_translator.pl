#!/usr/bin/perl
use strict;
use warnings;
use FindBin;
use lib "$FindBin::Bin/lib";
use RSSserver;

my $server = RSSserver->new(8080);
$server->run();
