use utf8;

use strict;
use warnings;

use 진사마;
use 하얀_고양이;

$|++; # heat the buffer so hot that characters melt flow

my $JEEN = 진사마->하아악커;

my $whitecatz = 하얀_고양이->교주님부활;


my $대화 = '하악하악';

print "<ZEEN> ",$대화,"\n\n";

while (1) {
  sleep 1;
  $대화 = $JEEN->아왜욤($대화);
  print "<ZEEN> $대화\n";
  sleep 1;
  $대화 = $whitecatz->냐옹($대화);
  print "<하얀_냐옹> $대화\n";
}




