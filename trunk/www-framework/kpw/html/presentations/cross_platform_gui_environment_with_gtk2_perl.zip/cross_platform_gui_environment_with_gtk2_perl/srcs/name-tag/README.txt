1.  예제 프로그램을 돌리기 위해서는 다음 모듈을 설치해야 합니다:

    *   GD
    *   Gtk2

2.  파일 구성은 다음과 같습니다:
 
    *   README.txt
        -   현재 파일

    *   SeoulNamsanEB.ttf
        -   트루타입 폰트 파일

    *   gtk-lottery-event.pl
        -   경품 추첨용 gui 프로그램

    *   gtk-make-name-tag.pl
        -   이름표 생성용 gui 프로그램

    *   kpw2008-tag.pl
        -   mknametag.pl을 이용해서 이름표 일괄 생성하는 프로그램

    *   merge-three.pl
        -   출력에 적합하도록 이름표를 3개씩 합치는 프로그램

    *   mknametag.pl
        -   명령 인자를 이용해 이름표를 생성하는 프로그램

    *   name-tag-list.txt
        -   이름표 일괄 생성시 사용할 데이터

    *   name-tag-template.png
        -   이름표 생성시 사용할 배경 그림

    *   run.sh
        -   kpw2008-tag.pl 과 merge-three.pl 을 일괄 실행하는 프로그램
