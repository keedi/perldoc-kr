package RoJEEN;

use HTTP::Server::Simple::CGI;
use HTTP::Server::Simple::Static;

use base qw(HTTP::Server::Simple::CGI HTTP::Server::Simple::Static);

my %dispatch = (
    '/donate' => \&_donate,
    '/index' => \&_index,
    '/' => \&_index,
    );

sub handle_request {
  my $self = shift;
  my $cgi  = shift;

  my $path = $cgi->path_info();
  my $handler = $dispatch{$path};

#   if ($path eq '/') {
#     print $cgi->redirect('http://' . $self->host . ':' . $self->port . '/rojeen.html');
#   }
  if (ref($handler) eq "CODE") {
    $handler->($cgi);
  }
  elsif ($path =~ qr{\.(html|gif|jpg|png|css|js)}x) {
    $self->serve_static($cgi, '.');
  }
  else {
    print "HTTP/1.0 404 Not found\r\n";
    print $cgi->header,
          $cgi->start_html('Not found'),
          $cgi->h1('Not found'),
          $cgi->end_html;
  }
}

sub _index {
    my $cgi = shift;
    return if !ref $cgi;
    print "HTTP/1.0 302 Moved\r\n";
    print $cgi->redirect('http://localhost:8080/rojeen.html');
}

sub _donate {
  my $cgi  = shift;             # CGI.pm object
  return if !ref $cgi;

  my $name = $cgi->param('name') || undef;

  print "HTTP/1.0 200 OK\r\n";
  open my $fd, ">>", './donator_list.txt'
      or die "Couldn't create such file: $!";
 
  if (defined($name) && $name ne '') {
      print {$fd} $name,': ',$cgi->remote_host(),"\n";
      print $cgi->header('text/plain'), 'Thanks';
  }
  else {
      print {$fd} 'Naughty: ',$cgi->remote_host(),"\n";
      print $cgi->header('text/plain'), 'Die you scum';
  }
  close $fd;
}

