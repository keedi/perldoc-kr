use strict;
use warnings;
use RoJEEN;

my $server = RoJEEN->new(8080);
$server->run();

