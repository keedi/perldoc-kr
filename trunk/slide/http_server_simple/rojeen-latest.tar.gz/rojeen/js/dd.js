Ext.BLANK_IMAGE_URL = 'resources/images/default/s.gif';

Ext.namespace('DeathByDonate');

Ext.override(Ext.dd.DDProxy, {
    startDrag: function(x, y) {
        var dragEl = Ext.get(this.getDragEl());
        var el = Ext.get(this.getEl());
        var donator = Ext.get('donator');
        donator.applyStyles({'background-image' : 'url(images/donator.gif)'});

        var bubble1 = Ext.get('bubble1');
        bubble1.applyStyles({'background-image' : 'url(images/bubble_wot.gif)'});

        var jeen = Ext.get('jeen');
        jeen.applyStyles({'background-image' : 'url(images/jeen_dirty.gif)'});

        
        var bubble2 = Ext.get('bubble2');
        bubble2.applyStyles({'background-image' : 'url(images/bubble_jeen_sama.gif)'});
        
        dragEl.applyStyles({border:'','z-index':2000});
        dragEl.update(el.dom.innerHTML);
        dragEl.addClass(el.dom.className + ' dd-proxy');
    },
    onDragOver: function(e, targetId) {
        var target = Ext.get(targetId);
        this.lastTarget = target;

        var jeen = Ext.get('jeen');
        jeen.applyStyles({'background-image' : 'url(images/jeen_evil.gif)'});

        var bubble1 = Ext.get('bubble1');
        bubble1.applyStyles({'background-image' : 'none'});

        var donator = Ext.get('donator');
        donator.applyStyles({'background-image' : 'url(images/donator_init.gif)'});

        var bubble2 = Ext.get('bubble2');
        bubble2.applyStyles({'background-image' : 'url(images/bubble_kaa.gif)'});
        
    },
    onDragOut: function(e, targetId) {
        var target = Ext.get(targetId);
        this.lastTarget = null;

        var jeen = Ext.get('jeen');
        jeen.applyStyles({'background-image' : 'url(images/jeen_dirty.gif)'});

        var bubble1 = Ext.get('bubble1');
        bubble1.applyStyles({'background-image' : 'url(images/bubble_chet.gif)'});
    },
    endDrag: function() {
        var dragEl = Ext.get(this.getDragEl());
        var el = Ext.get(this.getEl());

        if(this.lastTarget) {
            Ext.get('dditem').remove();
            var jeen = Ext.get('jeen');
            jeen.applyStyles({'background-image' : 'url(images/jeen_eating.gif)'});
            
            var bubble1 = Ext.get('bubble1');
            bubble1.applyStyles({'background-image' : 'url(images/bubble_arg.gif)'});

            Ext.Ajax.request({
                url: '/donate',
                success: function(resp) {
                    if (resp.responseText == 'Thanks') {
                        Ext.get('notice').dom.innerHTML = 
                            '<p>당신의 작은 정성에 무한한 펄 실력을~</p><p>즐펄! </p>';
                  } else if (resp.responseText == 'Die you scum') {
                        Ext.get('notice').dom.innerHTML = 
                          '<p>당신의 IP를 기억해 놓았습니다.</p><p>쓰읍....</p>';
                    }
                },
                params: { name: Ext.get('nameIn').dom.value }
            });
        }
        else {
            el.applyStyles({position:'absolute'});
            el.setXY(dragEl.getXY());
            el.setWidth(dragEl.getWidth());
        }
    }
});

// create application
DeathByDonate.dd = function() {
    
    // private space


    return {
        
        // public methods
        init: function() {
            // drop zones
            var zone_jeen = new Ext.dd.DropZone('ddzone', {ddGroup:'group'});
            Ext.get('jeen').on('click', function(elem) { 
                Ext.get('bubble1').applyStyles({
                    'background-image' : 'url(images/bubble_hentai.gif)'
                });
            });
            
            // container 1
            var donator = Ext.get('dditem');
            donator.dd = new Ext.dd.DDProxy('dditem', 'group', {
                scope:this,
                ddXY: donator.getXY()
            });

            var interval = 0, donator_posX = donator.getX();
            
            window.setInterval(function() {
                if (interval % 2) {
                    donator.setX(donator_posX - 10);
                } else {
                    donator.setX(donator_posX + 10);
                }
                interval++;
            }, 500);
        }
    };
}(); // end of app

// end of file
